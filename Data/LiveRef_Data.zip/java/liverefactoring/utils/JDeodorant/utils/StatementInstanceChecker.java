package liverefactoring.utils.JDeodorant.utils;

import com.intellij.psi.PsiStatement;

interface StatementInstanceChecker {
    boolean instanceOf(PsiStatement statement);
}

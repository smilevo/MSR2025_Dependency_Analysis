package liverefactoring.core;

public enum Refactorings {
    ExtractMethod,
    ExtractClass,
    ExtractVariable,
    MoveMethod,
    IntroduceParamObj,
    StringComparison,
    InheritanceToDelegation,
    All
}

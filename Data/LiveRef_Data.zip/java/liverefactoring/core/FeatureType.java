package liverefactoring.core;

public enum FeatureType {
    DataFlow,
    ControlFlow,
    DataAndControlFlow,
}
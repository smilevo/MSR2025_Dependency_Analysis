package CH.ifa.draw.standard;

import CH.ifa.draw.framework.*;

public class FigureChangeAdapter implements FigureChangeListener {
	public void figureChanged(FigureChangeEvent e) {
	}

	public void figureInvalidated(FigureChangeEvent e) {
	}

	public void figureRemoved(FigureChangeEvent e) {
	}

	public void figureRequestRemove(FigureChangeEvent e) {
	}

	public void figureRequestUpdate(FigureChangeEvent e) {
	}
}
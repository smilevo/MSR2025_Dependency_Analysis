    private void dummpPhases() {
        PhaseMetaData phaseMetaData = new PhaseMetaData("service");
        phases.add(phaseMetaData);
        PhaseMetaData p1 = new PhaseMetaData("P1");
        phases.add(p1);
        PhaseMetaData p2 = new PhaseMetaData("P1");
        phases.add(p2);
        PhaseMetaData p3 = new PhaseMetaData("P3");
        phases.add(p3);
    }

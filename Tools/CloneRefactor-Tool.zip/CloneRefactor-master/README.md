# CloneRefactor
We bridged a gap between clone detection and refactoring by designing a tool that can detect clones by our refactoring-oriented clone types. This tool performs a comprehensive context analysis on the detected clones. Based on this this context, CloneRefactor can automatically refactor a subset of the detected clones by applying transformations to the source code of the analyzed software project(s).

Please read my thesis for more details of this tool.

mvn clean package -DskipTests

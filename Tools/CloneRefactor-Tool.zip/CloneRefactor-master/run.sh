mvn clean && mvn compile && mvn exec:java -e -X

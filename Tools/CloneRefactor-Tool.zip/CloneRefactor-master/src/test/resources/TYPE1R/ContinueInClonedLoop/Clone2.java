public class Clone2 {
	public void test2()
	{
		for(int i = 0; i<10; i++) {
			if(i == 5)
				continue;
			System.out.println("Clone");
		}
	}
}
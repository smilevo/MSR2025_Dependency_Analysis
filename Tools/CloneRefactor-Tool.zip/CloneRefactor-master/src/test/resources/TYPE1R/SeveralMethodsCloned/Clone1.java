
public class Clone1 {

	public static void main(String[] args) {
		System.out.println("I'm a clone");
	}
	
	public static void main2(String[] args) {
		System.out.println("I'm a clone");
	}
	
	public static void main3(String[] args) {
		System.out.println("I'm a clone");
	}

}

public class NoClone1 implements NoClone3 {
	public NoClone1() {}
}
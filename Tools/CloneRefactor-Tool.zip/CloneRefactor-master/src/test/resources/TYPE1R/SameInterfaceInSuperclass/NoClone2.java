public class NoClone2 implements NoClone3 {
	public NoClone2() {}
}
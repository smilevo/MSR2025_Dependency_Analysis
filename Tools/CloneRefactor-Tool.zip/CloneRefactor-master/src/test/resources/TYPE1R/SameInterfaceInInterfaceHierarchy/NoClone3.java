public interface NoClone3 {
	public NoClone3() {}
}
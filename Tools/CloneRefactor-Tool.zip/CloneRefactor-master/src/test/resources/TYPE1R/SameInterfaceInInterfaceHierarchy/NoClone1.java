public interface NoClone1 extends NoClone3 {
}
public interface NoClone2 extends NoClone3 {
}
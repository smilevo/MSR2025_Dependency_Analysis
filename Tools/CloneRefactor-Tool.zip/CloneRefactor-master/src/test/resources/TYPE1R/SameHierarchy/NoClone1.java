public class NoClone1 extends NoClone2 {
	public NoClone1() {}
}
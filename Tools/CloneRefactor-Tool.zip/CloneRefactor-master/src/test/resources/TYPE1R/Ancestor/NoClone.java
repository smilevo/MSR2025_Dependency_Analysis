public class NoClone extends Clone2 {
	public NoClone() {}
}
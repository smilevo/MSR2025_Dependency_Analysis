public class NoClone3 {
	public NoClone3() {}
}
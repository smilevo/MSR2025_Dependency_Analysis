public class NoClone2 extends NoClone3 {
	public NoClone2() {}
}
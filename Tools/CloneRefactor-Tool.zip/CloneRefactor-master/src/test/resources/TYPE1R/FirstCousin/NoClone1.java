public class NoClone1 extends NoClone3 {
	public NoClone1() {}
}
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class Clone2 {

	public static void main2(String[] args) {
		System.out.println("Hello World");
	}

}

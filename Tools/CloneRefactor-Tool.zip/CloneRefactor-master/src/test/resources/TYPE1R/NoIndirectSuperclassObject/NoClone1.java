public class NoClone1 extends Object {
	public NoClone1() {}
}
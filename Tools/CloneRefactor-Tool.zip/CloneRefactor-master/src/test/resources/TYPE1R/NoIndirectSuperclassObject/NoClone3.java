public class NoClone3 extends Object {
	public NoClone3() {}
}

public class Clone2 {

	public static void main2(String[] args) {
		System.out.println("I'm a clone");
		System.out.println("I'm a clone");
		System.out.println("I'm a clone");
		System.out.println("I'm a clone");
		System.out.println("I'm a clone");
		System.out.println("I'm a clone");
		System.out.println("I'm a clone");
		System.out.println("I'm a clone");
		System.out.println("I'm a clone");
		System.out.println("I'm a clone");
		System.out.println("I'm a clone");
		System.out.println("I'm a clone");
		System.out.println("I'm a clone");
	}

}

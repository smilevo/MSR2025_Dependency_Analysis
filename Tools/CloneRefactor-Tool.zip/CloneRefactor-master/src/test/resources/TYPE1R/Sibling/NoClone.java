public class NoClone {
	public NoClone() {}
}
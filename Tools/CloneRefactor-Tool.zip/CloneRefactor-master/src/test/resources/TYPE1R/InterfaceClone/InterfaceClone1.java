public interface InterfaceClone1 {

	public void clone1();
	public void clone2();
	public void clone3();
	public void clone4();
	public void clone5();
	public void clone6();
	public void clone7();
}

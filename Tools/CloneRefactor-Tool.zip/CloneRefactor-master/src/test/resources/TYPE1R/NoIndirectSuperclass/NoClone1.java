public class NoClone1 {
	public NoClone1() {}
}
public class Clone2 {
	public void test()
	{
		for(int i = 0; i<20; i++) {
			if(i == 5)
				break;
			System.out.println("Clone");
		}
	}
}
public class Clone2 {
	public void partialBlock2()
	{
		boolean isTrue = true;
		if (isTrue)
		{
			System.out.println("Hai");
		}
		else
		{
			System.out.println("cloned");
			System.out.println("cloned2");
			System.out.println("cloned3");
			System.out.println("cloned4");
			System.out.println("No clone");
		}
	}
}
public class Clone1 {
	public void partialBlock()
	{
		boolean isTrue = true;
		if (isTrue)
		{
			System.out.println("Hai");
		}
		else
		{
			System.out.println("cloned");
			System.out.println("cloned2");
			System.out.println("cloned3");
			System.out.println("cloned4");
			System.out.println("Not cloned!!!");
		}
	}
}
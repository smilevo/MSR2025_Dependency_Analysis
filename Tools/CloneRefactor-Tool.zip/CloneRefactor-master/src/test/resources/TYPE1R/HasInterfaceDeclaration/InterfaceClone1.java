public interface InterfaceClone {

	public void clone1();
	public void clone2();
	public void clone3();
	public void clone4();
	public void clone5();
	public void clone6();
	public void notAClone();
}

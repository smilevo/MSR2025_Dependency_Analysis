
public class Clone1 {

	public static void main(String[] args) {
		System.out.println("I'm a clone");
		System.out.println("I'm a clone");
		int i = 1+1;
		System.out.println("I'm a clone");
		System.out.println("I'm a clone");
		System.out.println("I'm a clone");
		int j = 1*2;
		System.out.println("I'm a clone");
		System.out.println("I'm a clone");
		
	}

}

public interface NoClone {
}
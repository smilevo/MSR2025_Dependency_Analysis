package nl.tudelft.jpacman.clone;

public enum CloneEnum {
	BLA,
	BLA1,
	BLA2,
	BLA3,
	BLA4,
	BLA5,
	BLA6,
	BLA7,
	BLA8,
	BLA9,
	BLA10,
	BLA11,
	BLA12,
	BLA13,
	BLA14,
	BLA15,
	BLA16,
	BLA17,
	BLA18,
	ILIKETODIFFER
}


public class Clone2 {

	private String clone1 = "I'm a clone1";
	private String clone2 = "I'm a clone2";
	private String clone3 = "I'm a clone3";
	private String clone4 = "I'm a clone4";
	private String clone5 = "I'm a clone5";
	private String clone6 = "I'm a clone6";
	private String clone7 = "I'm a clone7";

	public static void main2(String[] args) {
		System.out.println("not a clone :)");
	}

}

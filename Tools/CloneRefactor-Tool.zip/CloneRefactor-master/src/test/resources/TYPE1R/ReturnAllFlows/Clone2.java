public class Clone2 {
	public void partialBlock2()
	{
		if (true == false)
		{
			System.out.println("cloned");
			System.out.println("cloned2");
			System.out.println("cloned3");
			System.out.println("cloned4");
			return false;
		}
		System.out.println("not cloned");
		return true;
	}
}
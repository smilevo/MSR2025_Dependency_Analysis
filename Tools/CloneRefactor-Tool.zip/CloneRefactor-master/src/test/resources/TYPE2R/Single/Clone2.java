
public class Clone2 {

	public static void main2(String[] args) {
		System.out.println("I'm a clone123");
		System.out.println("I'm a clone1234");
		System.out.println("I'm a clone12345");
		System.out.println("I'm a clone123456");
		System.err.println("I differ");
		System.err.println("I like to differ");
		System.err.println("Also different");
		System.out.println("I'm a clone123");
		System.out.println("I'm a clone1234");
		System.out.println("I'm a clone12345");
		System.out.println("I'm a clone123456");
	}

}

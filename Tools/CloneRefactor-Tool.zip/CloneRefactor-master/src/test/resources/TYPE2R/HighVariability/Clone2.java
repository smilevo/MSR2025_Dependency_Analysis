
public class Clone2 {

	public static void main2(String[] args) {
		System.out.println("I'm a clone1");
		System.out.println("I'm a clone2");
		System.out.println("I'm a clone3");
		System.out.println("I'm a clone4");
		System.err.println("I differ");
		System.err.println("I like to differ");
		System.err.println("Also different");
		System.out.println("I'm a clone8");
		System.out.println("I'm a clone9");
		System.out.println("I'm a clone10");
		System.out.println("I'm a clone11");
		System.out.println("I'm a clone12");
	}

}

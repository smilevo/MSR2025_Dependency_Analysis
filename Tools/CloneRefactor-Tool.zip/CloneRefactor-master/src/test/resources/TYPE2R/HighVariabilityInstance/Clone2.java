
public class Clone2 {

	public static void main2(String[] args) {
		System.out.println("Different");
		System.out.println("Different");
		System.out.println("Different");
		System.out.println("Different");
		System.err.println("I differ");
		System.err.println("I like to differ");
		System.err.println("Also different");
		System.out.println("Different");
		System.out.println("Different");
		System.out.println("Different");
		System.out.println("Different");
		System.out.println("Different");
	}

}

package com.simonbaars.clonerefactor.detection.interfaces;

public interface HasSize {
	public int size();
}

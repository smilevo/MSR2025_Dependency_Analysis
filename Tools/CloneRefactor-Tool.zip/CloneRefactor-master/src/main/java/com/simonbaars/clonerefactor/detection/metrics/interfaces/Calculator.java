package com.simonbaars.clonerefactor.detection.metrics.interfaces;

public interface Calculator<T> {
	public int calculate(T t);
}

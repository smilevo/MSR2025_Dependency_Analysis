package com.simonbaars.clonerefactor.detection.model.location;

import com.github.javaparser.Range;

public interface HasRange {
	public Range getRange();
}

package com.simonbaars.clonerefactor.datatype.map;

public interface TableColumn {
	public String toString();
}

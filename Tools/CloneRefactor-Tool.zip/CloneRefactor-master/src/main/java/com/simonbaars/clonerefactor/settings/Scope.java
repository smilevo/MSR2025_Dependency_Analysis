package com.simonbaars.clonerefactor.settings;

public enum Scope {
	ALL, METHODSONLY, METHODBODYONLY
}

#!/bin/bash

docker build -t alanz/haskell-platform-2012.4.0.0-64 ./haskell-platform-2012.4.0.0-64

# docker push alanz/haskell-platform-2012.4.0.0-64



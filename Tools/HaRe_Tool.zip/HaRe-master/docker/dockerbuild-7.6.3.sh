#!/bin/bash

docker build -t alanz/haskell-platform-2013.2.0.0-64 ./haskell-platform-2013.2.0.0-64

# docker push alanz/haskell-platform-2013.2.0.0-64



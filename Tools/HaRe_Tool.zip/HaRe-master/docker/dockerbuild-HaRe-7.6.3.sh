#!/bin/bash

#cp ../HaRe.cabal ./HaRe-7.6.3/

docker build -t alanz/HaRe-7.6.3-64 ./HaRe-7.6.3

# docker push alanz/HaRe-7.6.3-64




module A1 where


f x y = x + y * 42

g = 42

module A2 where


f x y = x + y * 42


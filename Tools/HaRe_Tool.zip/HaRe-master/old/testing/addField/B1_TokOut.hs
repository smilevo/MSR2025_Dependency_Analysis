module B1 where

data Data1 b a = C1 b a Int Int | C2 Int | C3 Float


g = (C1 undefined 1 2 3)


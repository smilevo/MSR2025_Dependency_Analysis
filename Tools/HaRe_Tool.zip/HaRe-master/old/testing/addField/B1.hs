module B1 where

data Data1 a = C1 a Int Int |
               C2 Int        |
	       C3 Float


g = (C1 1 2 3)


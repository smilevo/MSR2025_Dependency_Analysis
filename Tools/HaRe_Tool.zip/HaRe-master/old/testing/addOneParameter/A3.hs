module A3 where
 
import D3

main = sumSquares [1..4]


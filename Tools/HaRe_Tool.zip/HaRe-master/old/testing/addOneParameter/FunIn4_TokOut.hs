module FunIn4 where

--Default parameters can be added to definition of functions and simple constants.

--In this example: add parameter 'y' to 'foo'

main::Int
main = sum [x+4 |let foo y =[1..4]

                     foo_y = undefined, x<-(foo foo_y)]
                          
module A3 where
 
import D3

main = (sumSquares sumSquares_y) [1..4]


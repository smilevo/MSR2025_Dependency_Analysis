#!/bin/sh

TESTING_DIR="$(pwd)"
cd ..
./UTest.sh $TESTING_DIR

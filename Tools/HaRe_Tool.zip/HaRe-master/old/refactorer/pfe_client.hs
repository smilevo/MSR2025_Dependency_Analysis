
-- a miniature client for a refactoring server
module Main where

import EditorCommands

main = clientCmd

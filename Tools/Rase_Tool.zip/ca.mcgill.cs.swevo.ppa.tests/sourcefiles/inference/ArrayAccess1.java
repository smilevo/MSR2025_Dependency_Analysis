package p1;

public class ArrayAccess1 extends SuperArrayAccess2 {
	
	public void main() {
		A1[] f1 = new A1[2];
		f2 = f1;
		f3[2] = f1[1];
		boolean[] f4 = new boolean[5];
		f5 = f4;
		f6[f8] = f4[f7];
	}
	
}
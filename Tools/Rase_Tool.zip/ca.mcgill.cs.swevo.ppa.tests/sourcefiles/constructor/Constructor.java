package p1;

public class Constructor {
	

	public Constructor() {
		
	}
	
	public Constructor(int i) {
		this();
	}
	
	public void main() {
		String s = new String();
		MyMy m = new MyMy();
	}
	
}


public interface HelloWorld {
	
	public FooHello getFoo();
	
	public BarHello getBar();
	
}
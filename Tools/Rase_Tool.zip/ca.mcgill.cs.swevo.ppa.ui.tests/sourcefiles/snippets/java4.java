

public class MySnippet {

	@MyAnnotation(param1="value1")
	public void method1() {
		System.out.println();
		method1();
	}
	
}
int field1 = 2;
private String field2 = "";
private Runnable runnable = new Runnable() {
  public void run() {

  }
};

static class Toto {
  public void toto() {

  }
}

public HelloWorld() {
  System.out.println("Bonjour!");
}
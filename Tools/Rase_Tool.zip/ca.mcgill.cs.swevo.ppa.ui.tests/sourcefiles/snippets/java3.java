 System.out.println("Bonjour!");
  int param1 = 2;
  Runnable runnable = new Runnable() {
    public void run() {

    }
  };
 System.out.println(param1);
package com.foo;

/**
 Hello World
**/

public class HelloWorld {
  int field1 = 2;
  private String field2 = "";

  public HelloWorld() {
    System.out.println("Bonjour!");
    MySuperDooperClass.method1();
    int param1 = 2;
    param1++;
  }
  
  

}
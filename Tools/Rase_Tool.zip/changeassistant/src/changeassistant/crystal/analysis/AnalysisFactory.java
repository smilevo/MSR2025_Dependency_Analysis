package changeassistant.crystal.analysis;

public class AnalysisFactory {

}

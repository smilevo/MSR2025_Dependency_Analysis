package changeassistant.main;

public class ProjectMethod {

	public String className1, className2;

	public String filePath1, filePath2;

	public String methodName1, methodName2;

	public ProjectMethod(String className1, String className2,
			String filePath1, String filePath2, String methodName1,
			String methodName2) {
		this.className1 = className1;
		this.className2 = className2;
		this.filePath1 = filePath1;
		this.filePath2 = filePath2;
		this.methodName1 = methodName1;
		this.methodName2 = methodName2;
	}
}

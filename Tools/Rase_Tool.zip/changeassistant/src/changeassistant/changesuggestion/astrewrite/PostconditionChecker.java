package changeassistant.changesuggestion.astrewrite;

public class PostconditionChecker {

}

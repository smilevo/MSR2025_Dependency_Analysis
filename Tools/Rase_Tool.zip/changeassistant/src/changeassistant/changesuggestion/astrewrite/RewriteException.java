package changeassistant.changesuggestion.astrewrite;

public class RewriteException extends Exception{
	public RewriteException(String str){
		super(str);
	}
}

package changeassistant.changesuggestion.astrewrite;

import java.util.ArrayList;
import java.util.List;

public class StringEditScript extends EditScript<String> {
}

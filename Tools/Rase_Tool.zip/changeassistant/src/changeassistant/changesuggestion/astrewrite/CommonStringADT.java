package changeassistant.changesuggestion.astrewrite;

public class CommonStringADT extends CommonADT<String> {

	public CommonStringADT(String commonElement, int left, int right) {
		super(commonElement, left, right);
		// TODO Auto-generated constructor stub
	}
}

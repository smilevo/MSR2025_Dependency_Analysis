package changeassistant.changesuggestion.astrewrite;

import java.util.List;

public class TokenEditScript extends EditScript<List<String>>{
}

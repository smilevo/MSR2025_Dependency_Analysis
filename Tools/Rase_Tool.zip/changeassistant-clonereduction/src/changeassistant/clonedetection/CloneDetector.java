package changeassistant.clonedetection;

/**
 * Call CCFinder to find clones
 * 
 * @author mn8247
 * 
 */
public class CloneDetector {

}

package changeassistant.clonereduction.datastructure;

import java.util.List;

public class MethodRelation {

	public boolean outerAndInnerClass;
	public boolean inSameClass;
	public boolean hasSameSuperClass;
	public List<String> supers;
	public String outerClassName;
}

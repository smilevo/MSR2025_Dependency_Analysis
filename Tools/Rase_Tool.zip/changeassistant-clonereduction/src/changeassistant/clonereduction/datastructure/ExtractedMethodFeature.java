package changeassistant.clonereduction.datastructure;

public class ExtractedMethodFeature {

	public int modifiers;

	public ExtractedMethodFeature(int modifiers) {
		this.modifiers = modifiers;
	}
}

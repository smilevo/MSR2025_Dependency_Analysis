package changeassistant.clonereduction.manipulate;

import changeassistant.multipleexample.partition.datastructure.EditInCommonCluster;
import changeassistant.multipleexample.partition.datastructure.EditInCommonGroup;

public class CloneReductionTransformer {

	public static void createEdits(EditInCommonCluster cluster,
			EditInCommonGroup group) {

	}
}

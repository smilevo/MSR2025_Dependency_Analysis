package changeassistant.clonereduction.main;

public class CloneReductionException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4698957868659894981L;

	public CloneReductionException(String message){
		super(message);
	}
}

package changeassistant.multipleexample.contextualize;

public interface Constraint {

}

package changeassistant.multipleexample.contextualize;

import java.util.List;

import changeassistant.multipleexample.partition.datastructure.AbstractCluster;

public class ContentInCommonCluster extends AbstractCluster {

	@Override
	public boolean contains(Integer index) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int getIndex() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Integer> getInstances() {
		// TODO Auto-generated method stub
		return null;
	}

}

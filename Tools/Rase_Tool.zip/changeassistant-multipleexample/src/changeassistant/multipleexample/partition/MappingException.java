package changeassistant.multipleexample.partition;

public class MappingException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public MappingException(String e){
		super(e);
	}

}

package gr.uom.java.ast.decomposition.cfg;

import gr.uom.java.ast.decomposition.AbstractStatement;

public class CFGSynchronizedNode extends CFGBlockNode {
	public CFGSynchronizedNode(AbstractStatement statement) {
		super(statement);
	}
}

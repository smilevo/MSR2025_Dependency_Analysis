package ca.concordia.jdeodorant.clone.parsers;

public interface CloneDetectorOutputParserProgressObserver {
	public void notify(int cloneGroupIndex);
}

/**
 * Text-related classes.
 */
package org.jfree.chart.text;

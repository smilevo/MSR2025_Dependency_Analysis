/**
 * Classes related to the encoding of charts to different image formats.
 */
package org.jfree.chart.encoders;

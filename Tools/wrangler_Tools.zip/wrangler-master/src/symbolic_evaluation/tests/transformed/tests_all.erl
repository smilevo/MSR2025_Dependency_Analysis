%% @private
-module(tests_all).
-compile([export_all]).

testIfAndCase() -> 8.

testFlatten() -> [1,2,3,4,5,6,7,8,9].

testFunAll() -> 42.

testAll2() -> true.

